import java.util.ArrayList;
public class Food {
    ArrayList<ArrayList> foodlist = new ArrayList<ArrayList>();

    public void food(String line){

        ArrayList<Object> temp = new ArrayList<Object>();
        int index = 0;
        while (index < 3){
            temp.add(0);
            index++;
        }
        temp.set(1, "foodname");

        String[] Line = line.split("\t");

        int ID = Integer.parseInt(Line[0]);
        String name = Line[1];
        int Calories = Integer.parseInt(Line[2]);

        temp.set(0, ID);
        temp.set(1, name);
        temp.set(2, Calories);
        foodlist.add(temp);
    }

    public ArrayList<ArrayList> getFoodlist(){

        return foodlist;
    }
}
