import java.util.ArrayList;

public class Sports {
    ArrayList<ArrayList> sportlist = new ArrayList<ArrayList>();

    public void sports(String line){

        ArrayList<Object> temp = new ArrayList<Object>();
        int index = 0;
        while (index < 3){
            temp.add(0);
            index++;
        }
        temp.set(1, "sportname");

        String[] Line = line.split("\t");

        int ID = Integer.parseInt(Line[0]);
        String name = Line[1];
        int Calories = Integer.parseInt(Line[2]);

        temp.set(0, ID);
        temp.set(1, name);
        temp.set(2, Calories);
        sportlist.add(temp);
    }

    public ArrayList<ArrayList> getSportlist(){
        return sportlist;
    }
}
