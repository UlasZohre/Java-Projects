import java.util.ArrayList;
public class Person {

    ArrayList<ArrayList> personlist = new ArrayList<ArrayList>();

    public void person(String line){

        ArrayList<Object> temp = new ArrayList<>();
        int index = 0;
        while (index < 7){
            temp.add(0);
            index++;
        }

        temp.set(1, "name");

        String[] Line = line.split("\t");

        int ID = Integer.parseInt(Line[0]);
        String name = Line[1];
        String gender = Line[2];
        int weight = Integer.parseInt(Line[3]);
        int height = Integer.parseInt(Line[4]);
        int age = 2022 - Integer.parseInt(Line[5]);
        int CaloriNeed = 0;

        if( gender.equals("male")){
            CaloriNeed = (int) Math.round(66 + (13.75 * weight) + (5 * height) - ( 6.8 * age));
        }
        else if ( gender.equals("female")){
            CaloriNeed = (int) Math.round(665 + (9.6 * weight) + ( 1.7 * height) - (4.7* age));
        }

        temp.set(0, ID);
        temp.set(1, name);
        temp.set(2, CaloriNeed);
        temp.set(3, age);
		temp.set(4, 0); // calorie taken
		temp.set(5, 0); // calorie burned
		temp.set(6, 0); // result

        personlist.add(temp);

    }
    public ArrayList<ArrayList> getPersonlist(){
        return personlist;
    }
}
