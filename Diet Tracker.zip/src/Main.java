import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)throws IOException {
        FileWriter fw = new FileWriter(new File("monitoring.txt"));
        BufferedWriter bw = new BufferedWriter(fw);

        Person personlist = new Person();

        File persons = new File("people.txt");
        Scanner scannerperson = new Scanner(persons);
        String Line = null;

        while (scannerperson.hasNextLine()){
            Line = scannerperson.nextLine();
            personlist.person(Line);
        }

        Food foodlist = new Food();
        File foods = new File("food.txt");
        Scanner scannerfood = new Scanner(foods);

        while ( scannerfood.hasNextLine()){
            Line = scannerfood.nextLine();
            foodlist.food(Line);
        }


        Sports sporlist = new Sports();
        File sports = new File("sport.txt");
        Scanner sportscanner = new Scanner(sports);

        while (sportscanner.hasNextLine()){
            Line = sportscanner.nextLine();
            sporlist.sports(Line);
        }

        Calculations commandlist = new Calculations();
        commandlist.takepersonfoodandsport(personlist, foodlist, sporlist);
	
        File commands = new File(args[0]);
        Scanner scannercommands = new Scanner(commands);
        while (scannercommands.hasNextLine()){
            Line = scannercommands.nextLine();
            commandlist.calculations(Line, bw);
            if (scannercommands.hasNextLine()){
                bw.write("***************" + "\n");
            }
        }
		
        scannercommands.close();
        bw.close();
    }
}
