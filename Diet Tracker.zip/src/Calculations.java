import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Calculations {
    ArrayList<ArrayList> personlist = new ArrayList<ArrayList>();
    ArrayList<ArrayList> foodlist = new ArrayList<ArrayList>();
    ArrayList<ArrayList> sportlist = new ArrayList<ArrayList>();

    public void takepersonfoodandsport(Person persons, Food foods, Sports sports)throws IOException {

        personlist.addAll(persons.getPersonlist());
        foodlist.addAll(foods.getFoodlist());
        sportlist.addAll(sports.getSportlist());
    }

	private void writePersonToFile(ArrayList<Object> person, BufferedWriter bw) throws IOException
	{	
		/*
		0: ID
		1: name
		2: CaloriNeed
		3: age
		4: calorie taken
		5: calorie burned
		6: result
		*/
		
		if ((int) person.get(6) > 0)
			bw.write(person.get(1) + "\t" + person.get(3) + "\t" + person.get(2) + "kcal\t" + person.get(4) + "kcal\t" + person.get(5) + "kcal\t+" + person.get(6) + "kcal\n");
		else
			bw.write(person.get(1) + "\t" + person.get(3) + "\t" + person.get(2) + "kcal\t" + person.get(4) + "kcal\t" + person.get(5) + "kcal\t" + person.get(6) + "kcal\n");
	}

	private boolean isPersonPrintable(ArrayList<Object> person)
	{
		if ((int) person.get(4) > 0 || (int) person.get(5) > 0)
			return true;
		else 
			return false;
		
	}
	
	private boolean isPersonInWarnList(ArrayList<Object> person)
	{
		if ((int) person.get(6) < 0)
			return true;
		else
			return false;
		
	}
	
	
	private void setResultOfPerson(ArrayList<Object> person)
	{
		person.set(6, Math.round((int) person.get(4) - ((int) person.get(2) + (int)person.get(5))));
	}

    public void calculations(String line, BufferedWriter bw) throws IOException {

        if (!line.substring(0, 5).equals("print")) {
            String[] Line = line.split("\t");

            int personID = Integer.parseInt(Line[0]);
            int foodorsportID = Integer.parseInt(Line[1]);
            int portionorduration = Integer.parseInt(Line[2]);

            int Calorieburned = 0;
            int personindex = 0;

            if (foodorsportID >= 2000) {// person is doing some exercise.
                int sportindex = 0;
				// find index of the sport
                while (foodorsportID != (int) sportlist.get(sportindex).get(0)) {
                    sportindex++;
                }
				
				// calculate calorie burned due to the sport
                if (foodorsportID == (int) sportlist.get(sportindex).get(0)) {
                    Calorieburned = ((int) sportlist.get(sportindex).get(2) * portionorduration / 60);
                    Math.round(Calorieburned);
                }
				
				// write information
                bw.write(personID + "\t" + "has" + "\t" + "burned" + "\t" + Calorieburned + "kcal" + "\t" +
                        "thanks to" + "\t" + sportlist.get(sportindex).get(1) + "\n");
				
				// find index of the person
                while (personID != (int) personlist.get(personindex).get(0)) {
                    personindex++;
                }

				personlist.get(personindex).set(5, (int) personlist.get(personindex).get(5) + Calorieburned);
				
				setResultOfPerson(personlist.get(personindex));
				
            } else if (foodorsportID < 2000) {

                int foodindex = 0;

                while (foodorsportID != (int) foodlist.get(foodindex).get(0)) {
                    foodindex++;
                }
				
                if (foodorsportID == (int) foodlist.get(foodindex).get(0)) {
                    Calorieburned = (int) foodlist.get(foodindex).get(2) * portionorduration;
                    Math.round(Calorieburned);
                }
			
				
                bw.write(personID + "\t" + "has" + "\t" + "taken" +"\t" + Calorieburned + "kcal" + "\t" + "from" +
                         "\t" +foodlist.get(foodindex).get(1) + "\n");

                while (personID != (int) personlist.get(personindex).get(0)) {
                    personindex++;
                }

				personlist.get(personindex).set(4, (int) personlist.get(personindex).get(4) + Calorieburned);
				
				setResultOfPerson(personlist.get(personindex));
            }
        }
		
        else if (line.substring(0, 5).equals("print")) {
            if (line.substring(5, 9).equals("List")) {
				int numberOfPrintedPeople = 0;
				for (int i = 0; i < personlist.size(); i++) {
					ArrayList<Object> person = personlist.get(i);
					if (isPersonPrintable(person)) {
						numberOfPrintedPeople += 1;
						writePersonToFile(person, bw);
					}
				}
                if (numberOfPrintedPeople == 0) {
                    bw.write("There" + "\t" + "is\tno" + "\t" + "such" + "\t" + "person" + "\n");
                }
            }

            else if (line.substring(5, 9).equals("Warn")) {
				int numberOfPrintedPeople = 0;
				for (int i = 0; i < personlist.size(); i++) {
					ArrayList<Object> person = personlist.get(i);
					if (isPersonInWarnList(person)) {
						numberOfPrintedPeople += 1;
						writePersonToFile(person, bw);
					}
				}
				
                if (numberOfPrintedPeople == 0) {
                    bw.write("There" + "\t" + "is\tno" + "\t" + "such" + "\t" + "person");
                }
            }

            else {//print(11234) between 6 and 11 id number.
                int personID = 0;
                String tempname = null;
                personID = Integer.parseInt(line.substring(6, 11));
				int indexOfPerson = -1;
                for (int i = 0; i < personlist.size(); i++) {
                    if (personID == (int) personlist.get(i).get(0)) {
						indexOfPerson = i;
						break;
                    }
                }
				ArrayList<Object> person = personlist.get(indexOfPerson);
				writePersonToFile(person, bw);


            }
        }
    }
}