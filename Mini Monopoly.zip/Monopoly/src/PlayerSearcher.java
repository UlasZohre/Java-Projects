public class PlayerSearcher {

    public static Players playersearcher(String line){



        if (line.substring(0,8).equals("Player 1")){
           return Main.getPlayer1();
        }

        else{
            return Main.getPlayer2();
        }

    }

    public static Players playersearcherv2(String line){
        if (line.substring(0,8).equals("Player 1")){
            return Main.getPlayer2();
        }

        else{
            return Main.getPlayer1();
        }
    }




}
