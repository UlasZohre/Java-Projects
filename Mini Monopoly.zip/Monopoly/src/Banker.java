public class Banker {
    int Current = 100000;

    public int getCurrent(){
        return Current;
    }
    public int setCurrentincome(int cost){
        Current = Current + cost;
        return Current;
    }
    public int setCurrentcost(int cost){
        Current = Current - cost;
        return Current;
    }
}
