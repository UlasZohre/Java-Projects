public class Property extends Squares {





}

