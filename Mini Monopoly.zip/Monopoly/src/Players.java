import java.util.ArrayList;

public class Players {

    String name = null;

    public String getName() {
        return name;
    }

    public String setName(String newName){
        name = newName;
        return name;
    }

    int Current = 15000;

    int jaildays = 0;

    int ownedRR = 0;

    public int getCurrent(){
        return Current;
    }

    public void setCurrentincome(int income){
        Current = Current + income;
    }

    public void setCurrentcost(int cost){
        Current = Current - cost;
    }

    public int location = 0; //yazdırırken 1 ekleyecek olabilirsin.

    public int getLocation(){
        return location;
    }

    public void setLocation(int newLocation){
        location = newLocation;
    }

    public void setLocation(){
        location = location - 3;
    }


    public int getJaildays(){
        return jaildays;
    }

    public void setJaildays(int days){
        jaildays = jaildays + days;
    }

    public int getOwnedRR(){
        return ownedRR;
    }

    public void setOwnedRR(int rr){
        ownedRR = ownedRR + rr;
    }

    public ArrayList<String> PropertyList = new ArrayList<String>();

    public ArrayList<String> getPropertyList(){
        return PropertyList;
    }

    public void setPropertyList(String PropertyName){
        this.PropertyList.add(PropertyName);
    }

    public String PropertyListObjects(ArrayList<String> PropertyList){
        String temp = "";
        for( String string : PropertyList){
            temp += string + " ";
        }

        return temp;
    }
}

