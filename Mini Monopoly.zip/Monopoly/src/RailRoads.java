public class RailRoads extends Property{
    //* oyuncunun sırasında karşıdaki oyuncunun kaç tane rr si varsa 25 le çarpacaksın.



}
