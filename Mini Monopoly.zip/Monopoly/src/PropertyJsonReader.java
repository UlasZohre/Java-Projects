import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;


public class PropertyJsonReader {

    ArrayList<Squares> SquareList = new ArrayList<>();


    public PropertyJsonReader() throws IOException{

        JSONParser processor = new JSONParser();
        try (Reader file = new FileReader("Property")){
            JSONObject jsonfile = (JSONObject) processor.parse(file);
            JSONArray Land = (JSONArray) jsonfile.get("1");
            for(Object i:Land){
                Squares tempLand = new Land();

                //You can reach items by using statements below:
                int id = Integer.parseInt((String)((JSONObject)i).get("id"));
                String squareName = (String)((JSONObject)i).get("name");
                int cost = Integer.parseInt((String)((JSONObject)i).get("cost"));
                //And you can add these items to any data structure (e.g. array, linkedlist etc.
                tempLand.setID(id);
                tempLand.setName(squareName);
                tempLand.setCost(cost);
                tempLand.setType("Land");

                SquareList.add(tempLand);

            }
            JSONArray RailRoad = (JSONArray) jsonfile.get("2");
            for(Object i:RailRoad){
                Squares tempLand = new RailRoads();
                //You can reach items by using statements below:
                int id = Integer.parseInt((String)((JSONObject)i).get("id"));
                String squareName = (String)((JSONObject)i).get("name");
                int cost = Integer.parseInt((String)((JSONObject)i).get("cost"));
                //And you can add these items to any data structure (e.g. array, linkedlist etc.

                tempLand.setID(id);
                tempLand.setName(squareName);
                tempLand.setCost(cost);
                tempLand.setType("RailRoad");

                SquareList.add(tempLand);
            }

            JSONArray Company = (JSONArray) jsonfile.get("3");
            for(Object i:Company){
                Company tempLand = new Company();
                //You can reach items by using statements below:
                int id = Integer.parseInt((String)((JSONObject)i).get("id"));
                String squareName = (String)((JSONObject)i).get("name");
                int cost = Integer.parseInt((String)((JSONObject)i).get("cost"));

                tempLand.setID(id);
                tempLand.setName(squareName);
                tempLand.setCost(cost);
                tempLand.setType("Company");

                SquareList.add(tempLand);
            }

            Squares Go = new Squares();
            Go.setID(1);
            Go.setName("Go");
            SquareList.add(Go);

            CommunityChest cm1 = new CommunityChest();
            cm1.setID(3);
            cm1.setName("Community Chest");
            cm1.setType("Community Chest");
            SquareList.add(cm1);

            Squares incometax = new Squares();
            incometax.setID(5);
            incometax.setName("Income Tax");
            SquareList.add(incometax);

            Chance c1 = new Chance();
            c1.setID(8);
            c1.setName("Chance");
            c1.setType("Chance");
            SquareList.add(c1);

            Squares jail = new Squares();
            jail.setID(11);
            jail.setName("Jail");
            SquareList.add(jail);

            CommunityChest cm2 = new CommunityChest();
            cm2.setID(18);
            cm2.setName("Community Chest");
            cm2.setType("Community Chest");
            SquareList.add(cm2);

            Squares freeParking = new Squares();
            freeParking.setID(21);
            freeParking.setName("Free Parking");
            SquareList.add(freeParking);

            Chance c2 = new Chance();
            c2.setID(23);
            c2.setName("Chance");
            c2.setType("Chance");
            SquareList.add(c2);

            Squares goToJail = new Squares();
            goToJail.setID(31);
            goToJail.setName("Go to Jail");
            SquareList.add(goToJail);

            CommunityChest cm3 = new CommunityChest();
            cm3.setID(34);
            cm3.setName("Community Chest");
            cm3.setType("Community Chest");
            SquareList.add(cm3);

            Chance c3 = new Chance();
            c3.setID(37);
            c3.setName("Chance");
            c3.setType("Chance");
            SquareList.add(c3);

            Squares superTax = new Squares();
            superTax.setID(39);
            superTax.setName("Super Tax");
            SquareList.add(superTax);




        } catch (IOException e){
            e.printStackTrace();
        } catch (ParseException e){
            e.printStackTrace();
        }

    }
    public ArrayList<Squares> getSquareList(){
        return SquareList;
    }
}
    //You can add function(s) if you want
