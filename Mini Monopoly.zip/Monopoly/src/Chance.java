import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Chance extends Squares{

    public static void chance(Players tempname, Players tempname2,  int chanceIndex, BufferedWriter bw, int Dice, int position,
                              int communitychestindex, int location, ArrayList<Squares> Map) throws IOException {

        Players Player2 = Main.getPlayer2();
        Players Player1 = Main.getPlayer1();
        Banker banker = Main.getBank();

        ArrayList<String> Chancelist = (ArrayList<String>) ListJsonReader.getchancelist();


        if (Chancelist.get(chanceIndex).equals("Advance to Go (Collect $200)")){
            tempname.setCurrentincome(200);
            tempname.setLocation(0);
            banker.setCurrentcost(200);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +" draw Chance " + Chancelist.get(chanceIndex) + "\n");

        }

        else if (Chancelist.get(chanceIndex).equals("Advance to Leicester Square")){
            tempname.setLocation(26);
            if (Map.get(26).getOccupied() == 0){
                tempname.setCurrentcost(Map.get(26).getCost());
                banker.setCurrentincome(Map.get(26).getCost());
                Map.get(26).setOccupied();
                tempname.setPropertyList(Map.get(26).getName());
                bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                        Player2.getCurrent() +"\t" +
                        tempname.getName() +" draw Chance" + Chancelist.get(chanceIndex) + "and bought" +
                        Map.get(26).getName() + "\n");
            }
            else if (Map.get(26).getOccupied() == 1){
                tempname.setCurrentcost(Map.get(26).getRent());
                tempname2.setCurrentincome(Map.get(26).getRent());
                bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                        Player2.getCurrent() +"\t" +
                        tempname.getName() +" draw Chance" + Chancelist.get(chanceIndex) + "and paid rent for " + Map.get(26).getName() + "\n");
            }
        }
        else if (Chancelist.get(chanceIndex).equals("Go back 3 spaces")){
            tempname.setLocation();

            if (tempname.getLocation() == 0) {
                bw.write(tempname.getName() + "\t" + Dice + "\t" + position + "\t" + Player1.getCurrent() + "\t" +
                        Player2.getCurrent() + "\t" +
                        tempname.getName() + " draw Chance " + Chancelist.get(chanceIndex) + "\n");
            }

            else if (tempname.getLocation() == 19){
                if (Map.get(19).getOccupied() == 0){
                    tempname.setCurrentcost(Map.get(19).getCost());
                    banker.setCurrentincome(Map.get(19).getCost());
                    Map.get(19).setOccupied();
                }
                else if (Map.get(19).getOccupied() == 1){
                    tempname.setCurrentcost(Map.get(19).getRent());
                    tempname2.setCurrentincome(Map.get(19).getRent());
                }


            }

            else if (tempname.getLocation() == 33){
                if (communitychestindex == 0){
                    tempname.setLocation(0);
                    position = tempname.getLocation() + 1;
                }

                else{
                    tempname.setLocation(location);
                }

                CommunityChest.communityChest(tempname, tempname2, communitychestindex, bw, Dice, position);


                communitychestindex++;

            }
        }
        else if (Chancelist.get(chanceIndex).equals("Pay poor tax of $15")){
            tempname.setCurrentcost(15);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +" draw Chance " + Chancelist.get(chanceIndex) + "\n");
        }

        else if (Chancelist.get(chanceIndex).equals("Your building loan matures - collect $150")){
            tempname.setCurrentincome(150);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +" draw Chance " + Chancelist.get(chanceIndex) + "\n");
        }
        else if (Chancelist.get(chanceIndex).equals("You have won a crossword competition - collect $100 ")){
            tempname.setCurrentincome(100);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +" draw Chance " + Chancelist.get(chanceIndex) + "\n");
        }
    }
}
