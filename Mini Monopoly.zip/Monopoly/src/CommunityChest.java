import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;

public class CommunityChest extends Squares{

    public static void communityChest(Players tempname, Players tempname2, int communityChestIndex, BufferedWriter bw,
                                      int Dice, int position) throws IOException {
        Banker banker = Main.getBank();
        Players Player1 = Main.getPlayer1();
        Players Player2 = Main.getPlayer2();
        ArrayList<String> communityChestList = (ArrayList<String>) ListJsonReader.getcommunitychestlist();

        if (communityChestList.get(communityChestIndex).equals("Advance to Go (Collect $200)")) {
            tempname.setLocation(0);
            tempname.setCurrentincome(200);
            banker.setCurrentcost(200);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +" draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("Bank error in your favor - collect $75")) {
            tempname.setCurrentincome(75);
            banker.setCurrentcost(75);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("Doctor's fees - Pay $50")) {
            tempname.setCurrentcost(50);
            banker.setCurrentincome(50);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("It is your birthday Collect $10 from each player")) {
            tempname.setCurrentincome(10);
            tempname2.setCurrentcost(10);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("Grand Opera Night - collect $50 from every player for opening night seats")) {
            tempname.setCurrentincome(50);
            tempname2.setCurrentcost(50);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("Income Tax refund - collect $20")) {
            tempname.setCurrentincome(20);
            banker.setCurrentcost(20);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("Life Insurance Matures - collect $100")) {
            tempname.setCurrentincome(100);
            banker.setCurrentcost(100);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");

        }

        else if (communityChestList.get(communityChestIndex).equals("Pay Hospital Fees of $100")) {
            tempname.setCurrentcost(100);
            banker.setCurrentincome(100);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("Pay School Fees of $50")) {
            tempname.setCurrentcost(50);
            banker.setCurrentincome(50);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("You inherit $100")) {
            tempname.setCurrentincome(100);
            banker.setCurrentcost(100);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }

        else if (communityChestList.get(communityChestIndex).equals("From sale of stock you get $50")){
            tempname.setCurrentincome(50);
            banker.setCurrentcost(50);
            bw.write(tempname.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                    Player2.getCurrent() +"\t" +
                    tempname.getName() +"draw Community Chest " + communityChestList.get(communityChestIndex) + "\n");
        }
    }
}
