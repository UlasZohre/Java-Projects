import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;


public class ListJsonReader{

    private static ArrayList<String> chancelist = new ArrayList<>();

    private static ArrayList<String> communitychestlist = new ArrayList<>();


    public static void ListJsonReader() throws IOException{
        JSONParser processor = new JSONParser();
        try (Reader file = new FileReader("List")){
            JSONObject jsonfile = (JSONObject) processor.parse(file);
            JSONArray chanceList = (JSONArray) jsonfile.get("chanceList");
            for(Object i:chanceList){

                String card = ((String)((JSONObject)i).get("item"));

                chancelist.add(card);

                 /*
				 You can reach items by using:
				 ((String)((JSONObject)i).get("item"));
				 And you can add these items to any datastructure (e.g. array, linkedlist, etc.)
				 */

            }
            JSONArray communityChestList = (JSONArray) jsonfile.get("communityChestList");
            for(Object i:communityChestList){
                String card = ((String)((JSONObject)i).get("item"));
                communitychestlist.add(card);

                //You can reach items by using:

                //And you can add these items to any datastructure (e.g. array, linkedlist, etc.)

            }
        }catch (IOException e){
            e.printStackTrace();
        }catch (ParseException e){
            e.printStackTrace();
        }
    }

    public static List<String> getchancelist(){
        return chancelist;
    }

    public static List<String> getcommunitychestlist(){
        return communitychestlist;
    }
    //You can add function if you want
}

