public class Company extends Property{
    // rent = dice*4

    public void company(int dice){
        rent = 4*dice;
    }
}
