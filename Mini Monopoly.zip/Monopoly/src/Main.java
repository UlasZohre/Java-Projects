import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {
    static Players Player1 = new Players();
    static Players Player2 = new Players();
    static Banker bank = new Banker();





    public static void main(String[] args) throws IOException {
        Player1.setName("Player 1");
        Player2.setName("Player 2");

        PropertyJsonReader PJR = new PropertyJsonReader();
        ListJsonReader.ListJsonReader();
        ArrayList<Squares> Map = PJR.getSquareList();

        FileWriter fw = new FileWriter(new File("output.txt"));
        BufferedWriter bw = new BufferedWriter(fw);


        Collections.sort(Map, new Comparator<Squares>() {
            @Override
            public int compare(Squares o1, Squares o2) {
                return Integer.valueOf(o1.getID()).compareTo(o2.getID());
            }
        });

        //Map and players are ready.

        int chanceIndex = 0;
        int communityChestIndex = 0;
        int position = 0;

        File commands = new File(args[0]);
        Scanner commandScanner = new Scanner(commands);
        while (commandScanner.hasNextLine()){

            String Line = commandScanner.nextLine();


            if (Line.equals("show()")){
                bw.write("--------------------------------------------------------------------" +
                        "-----------------------------------------------------" + "\n");
                bw.write("Player 1\t" + Player1.getCurrent() + "\t" + "have: " +
                        Player1.PropertyListObjects(Player1.getPropertyList()) + "\n");
                bw.write("Player 2\t" + Player2.getCurrent() + "\t" + "have: " +
                        Player2.PropertyListObjects(Player2.getPropertyList()) + "\n");
                bw.write("Banker\t" + bank.getCurrent() + "\n");
                if (Player2.getCurrent()>Player1.getCurrent()){
                    bw.write("Winner Player 2" + "\n");
                }
                else{
                    bw.write("Winner Player 1" + "\n");
                }
                bw.write("---------------------------------------------------------------" +
                        "----------------------------------------------------------" + "\n");

            }

            else {
                Players tempName = PlayerSearcher.playersearcher(Line);
                Players tempName2 = PlayerSearcher.playersearcherv2(Line);
                int location = tempName.getLocation();
                int Dice = Integer.parseInt(Line.substring(9));
                //System.out.println(Dice); Dice ı doğru alıyor


                if (tempName.getJaildays() > 0){
                    tempName.setJaildays(-1);
                    bw.write(tempName.getName() + "\t" + Dice +"\t" + (tempName.getLocation()+1) + "\t"+
                            Player1.getCurrent() + "\t" + Player2.getCurrent() +
                            "\t" + tempName.getName() + " is in jail. Jail days:" + (3-tempName.getJaildays()) + "\n");
                }



                else {
                    if (location + Dice >= 40) {
                        location = location + Dice - 40;
                        tempName.setCurrentincome(200);
                        bank.setCurrentcost(200);
                    }
                    else{
                        location = location + Dice;
                    }

                    tempName.setLocation(location);

                    position = location + 1;





                    if (Map.get(location).gettype().equals("Land")) {

                        Map.get(location).setRent();
                        if (Map.get(location).getOccupied() == 0){

                            if (tempName.getCurrent() <= Map.get(location).getCost()){
                                tempName.setCurrentcost(tempName.getCurrent());
                                break;
                            }
                            tempName.setCurrentcost(Map.get(location).getCost());
                            Map.get(location).setOccupied();
                            bank.setCurrentincome(Map.get(location).getCost());
                            tempName.setPropertyList(Map.get(location).getName());


                            bw.write(tempName.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                                    Player2.getCurrent() +"\t" +
                                    tempName.getName() + " bought " + Map.get(location).getName() + "\n");
                        }

                        else if (Map.get(location).getOccupied() == 1){

                            if (tempName.getCurrent() <= Map.get(location).getRent()){
                                tempName.setCurrentcost(Map.get(location).getRent());
                                break;
                            }
                            tempName.setCurrentcost(Map.get(location).getRent());
                            tempName2.setCurrentincome(Map.get(location).getRent());
                            tempName.setLocation(location);


                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " paid rent for " +
                                    Map.get(location).getName() + "\n");

                        }
                    }

                    else if (Map.get(location).gettype().equals("RailRoad")){
                        if (Map.get(location).getOccupied() == 0){
                            if (tempName.getCurrent() <= Map.get(location).getCost()){
                                tempName.setCurrentcost(tempName.getCurrent());
                                break;
                            }
                            tempName.setCurrentcost(Map.get(location).getCost());
                            Map.get(location).setOccupied();
                            bank.setCurrentincome(Map.get(location).getCost());
                            tempName.setOwnedRR(1);
                            tempName.setPropertyList(Map.get(location).getName());


                            bw.write(tempName.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                                    Player2.getCurrent() +"\t" +
                                    tempName.getName() + " bought " + Map.get(location).getName() + "\n");

                        }

                        else if (Map.get(location).getOccupied() == 1){

                            if (tempName.getCurrent() <= tempName2.getOwnedRR()*25){
                                tempName.setCurrentcost(tempName.getCurrent());
                                break;
                            }
                            tempName.setCurrentcost(tempName2.getOwnedRR()*25);
                            tempName2.setCurrentincome(tempName2.getOwnedRR()*25);


                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " paid rent for " +
                                    Map.get(location).getName() + "\n");
                        }

                    }

                    else if (Map.get(location).gettype().equals("Company")){

                        if (Map.get(location).getOccupied() == 0){

                            if (tempName.getCurrent() <= Map.get(location).getCost()){
                                tempName.setCurrentcost(tempName.getCurrent());
                                break;
                            }

                            tempName.setCurrentcost(Map.get(location).getCost());
                            bank.setCurrentincome(Map.get(location).getCost());
                            tempName.setPropertyList(Map.get(location).getName());
                            Map.get(location).setOccupied();


                            bw.write(tempName.getName() +"\t"+ Dice +"\t"+ position +"\t" + Player1.getCurrent() +"\t"+
                                    Player2.getCurrent() +"\t" +
                                    tempName.getName() + " bought " + Map.get(location).getName() + "\n");
                        }

                        else{
                            if (tempName.getCurrent() <= Dice*4){
                                tempName.setCurrentcost(tempName.getCurrent());
                                break;
                            }
                            tempName.setCurrentcost(Map.get(location).getRent());
                            tempName2.setCurrentincome(Map.get(location).getRent());


                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " paid rent for " +
                                    Map.get(location).getName() + "\n");
                        }
                    }

                    else if (Map.get(location).gettype().equals("Chance")){
                        if (chanceIndex >= 6){
                            chanceIndex = chanceIndex - 6;
                        }
                        if (chanceIndex == 0){
                            tempName.setLocation(0);
                            position = tempName.getLocation() + 1;
                        }

                        else{
                            tempName.setLocation(location);
                        }
                        Chance.chance(tempName, tempName2, chanceIndex, bw, Dice, position, communityChestIndex, location,
                                Map);
                        chanceIndex++;

                        if (tempName.getCurrent() <= 0){
                            tempName.setCurrentcost(-tempName.getCurrent());
                            break;
                        }
                    }

                    else if (Map.get(location).gettype().equals("Community Chest")){

                        if (communityChestIndex >= 11){
                            communityChestIndex = communityChestIndex -11;
                        }
                        if (communityChestIndex == 0){
                            tempName.setLocation(0);
                            position = tempName.getLocation() + 1;
                        }

                        else{
                            tempName.setLocation(location);
                        }

                        CommunityChest.communityChest(tempName, tempName2, communityChestIndex, bw, Dice, position);


                        communityChestIndex++;

                        if (tempName.getCurrent() <= 0){
                            tempName.setCurrentcost(-tempName.getCurrent());
                            break;
                        }
                    }


                    else if (Map.get(location).gettype().equals("null")){

                        if (location == 0){
                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " is on Go Square" + "\n");

                        }

                        else if (location == 4){

                            if (tempName.getCurrent() <= 100){
                                tempName.setCurrentcost(tempName.getCurrent());
                                break;
                            }
                            tempName.setCurrentcost(100);
                            bank.setCurrentincome(100);
                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " in on Tax Square and paid tax." + "\n");
                        }

                        else if (location == 10){
                            tempName.setJaildays(3);
                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " went to jail. Jail days count " +
                                    (3-tempName.getJaildays()) + "\n");
                        }

                        else if (location == 20){
                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " is on Free Parking Lot" + "\n");
                        }

                        else if (location == 30){
                            tempName.setLocation(10);
                            tempName.setJaildays(3);
                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " went to jail. Jail days count " +
                                    (3-tempName.getJaildays()) + "\n");
                        }

                        else if (location == 38){
                            if (tempName.getCurrent() <= 100){
                                tempName.setCurrentcost(tempName.getCurrent());
                                break;
                            }
                            tempName.setCurrentcost(100);
                            bank.setCurrentincome(100);
                            bw.write(tempName.getName() + "\t" + Dice +  "\t"+ position +  "\t"+ Player1.getCurrent() +  "\t"
                                    + Player2.getCurrent() +  "\t" + tempName.getName() + " in on Tax Square and paid tax." + "\n");
                        }




                    }
                }
                if (tempName.getCurrent()<= 0){
                    break;
                }
                else if (tempName2.getCurrent() <= 0){
                    break;
                }
            }




        }
        bw.write("--------------------------------------------------------------------" +
                "-----------------------------------------------------" + "\n");
        bw.write("Player 1\t" + Player1.getCurrent() + "\t" + "have: " +
                Player1.PropertyListObjects(Player1.getPropertyList()) + "\n");
        bw.write("Player 2\t" + Player2.getCurrent() + "\t" + "have: " +
                Player2.PropertyListObjects(Player2.getPropertyList()) + "\n");
        bw.write("Banker\t" + bank.getCurrent() + "\n");
        if (Player2.getCurrent()>Player1.getCurrent()){
            bw.write("Winner Player 2" + "\n");
        }
        else{
            bw.write("Winner Player 1" + "\n");
        }
        bw.write("---------------------------------------------------------------" +
                "----------------------------------------------------------" + "\n");
        bw.close();

    }

    public static Players getPlayer1(){
        return Player1;
    }

    public static Players getPlayer2(){
        return Player2;
    }

    public static Banker getBank(){
        return bank;
    }

}
