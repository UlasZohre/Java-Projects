public class Squares{
    int id = 0;

    public int getID(){return this.id;}

    public int setID(int newID){
        this.id = newID;
        return id;
    }

    String name = null;

    public String getName(){return this.name;}

    public String setName(String newName){
        this.name = newName;
        return name;
    }
    String type = "null";

    public String gettype(){
        return type;
    }

    public String setType(String newType){
        this.type = newType;
        return type;
    }
    public int occupied = 0;

    public int getOccupied(){
        return occupied;
    }

    public int setOccupied(){
        occupied++;
        return occupied;
    }

    int cost = 0;

    public int getCost(){
        return cost;
    }

    public int setCost(int newCost){
        this.cost = newCost;
        return cost;
    }



    int rent = 0;

    public int getRent(){
        return rent;
    }

    public int setRent(){
        if (cost <= 2000){
            rent = (cost*40)/100;
        }

        else if ( cost <= 3000){
            rent = (cost*30)/100;
        }

        else if (cost <= 4000){
            rent = (cost*35)/100;
        }
        return rent;
    }
}

