public class Land extends Property{









}



