import java.util.ArrayList;


public class ArrangeMap {

    public static void  arrangeMap(ArrayList<ArrayList<Tile>> map){
        int x = 0;
        int y = 0;

        while (y < map.get(x).size()){
            ArrayList<Tile> tempArr = new ArrayList<>();
            while(x < map.size()){
                if (!map.get(x).get(y).getName().equals(" ")){
                    tempArr.add(map.get(x).get(y));
                }
                map.get(x).set(y, new Tile());

                x++;
            }
            x = 0;
            int TempIndex = 0;
            for (int Index = map.size()- tempArr.size(); Index < map.size(); Index++){
                map.get(Index).set(y, tempArr.get(TempIndex));
                TempIndex++;
            }
            y++;
        }
    }



}
