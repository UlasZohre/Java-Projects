import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Map {
    public ArrayList<ArrayList<Tile>> Board = new ArrayList<>();


    public Map(File file) throws FileNotFoundException {

        Scanner BoardScanner = new Scanner(file);

        while (BoardScanner.hasNextLine()){//Reads all lines and adds to board.
            String[] Line2 = BoardScanner.nextLine().split(" ");//Split spaces between letters
            ArrayList<Tile> Line = new ArrayList<>();
            for (int i = 0; i < Line2.length; i++){//checking letters in the line and creating object for according equality


                //if anyone want add another letter or math operator just type here another else if commandline

                if (Line2[i].equals("D")){
                    Tile newDiamond = new Diamond();
                    Line.add(newDiamond);
                }

                else if (Line2[i].equals("S")){
                    Tile newSqaure = new Square();
                    Line.add(newSqaure);
                }

                else if (Line2[i].equals("T")){
                    Tile newTriangle = new Triangle();
                    Line.add(newTriangle);
                }

                else if (Line2[i].equals("W")){
                    Tile newWildcard = new Wildcard();
                    Line.add(newWildcard);
                }

                else if (Line2[i].equals("+")){
                    Tile newPlus = new Plus();
                    Line.add(newPlus);
                }

                else if (Line2[i].equals("-")){
                    Tile newMinus = new Minus();
                    Line.add(newMinus);
                }

                else if (Line2[i].equals("/")){
                    Tile newDivide = new Divide();
                    Line.add(newDivide);
                }

                else if (Line2[i].equals("\\")){
                    Tile newBackslash = new Backslash();
                    Line.add(newBackslash);
                }

                else if (Line2[i].equals("|")){
                    Tile newStraightLine = new StraightLine();
                    Line.add(newStraightLine);
                }

            }

            setBoard(Line);// we need a setter for return a field variable
        }


    }

    public void printBoard(){
        for (int i = 0; i < Board.size(); i++){
            for (int j = 0; j< Board.get(i).size(); j++){
                System.out.print(Board.get(i).get(j) + " ");// every object will be printed
            }
            System.out.print("\n");//println is not working.
        }
    }

    public ArrayList<ArrayList<Tile>> setBoard(ArrayList<Tile> Line){//setter method
        Board.add(Line);
        return Board;
    }

    public ArrayList<ArrayList<Tile>> getBoard(){
        return Board;
    }









}
