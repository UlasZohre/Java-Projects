import java.util.ArrayList;

public class Backslash extends MathOperators {

    public Backslash(){
        Type = "\\";
        point = 20;
        isItMath = true;
        Name = "\\";
    }
    public String toString(){
        return Name;
    }

    public int Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y){
        // this one will control only 1 and 9 direction
        int counter = 1;

        if (x >= 2 && y >= 2) {//(1) left up diagonal both will decrease index wise
            if (map.get(x-1).get(y-1).isItMath){
                counter++;
            }

            if (map.get(x-2).get(y-2).getIsItMath()){
                counter++;
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() +map.get(x-1).get(y-1).getPoint() +
                        map.get(x-2).get(y-2).getPoint();


                map.get(x).get(y).setName(" ");

                map.get(x-1).get(y-1).setName(" ");

                map.get(x-2).get(y-2).setName(" ");


                return score;
            }

            else{
                counter = 1;
            }
        }

        if ( x < map.size()-2 && y < map.get(x).size()-2 ) {//(9) right down diagonal both will increase index wise
            if (map.get(x+1).get(y+1).getIsItMath()){
                counter++;
            }

            if (map.get(x+2).get(y+2).getIsItMath()){
                counter++;
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() + map.get(x+1).get(y+1).getPoint() +
                        map.get(x+2).get(y+2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x+1).get(y+1).setName(" ");
                map.get(x+2).get(y+2).setName(" ");
                return score;
            }

            else{
                counter = 1;
            }

        }
        return score;
    }
}
