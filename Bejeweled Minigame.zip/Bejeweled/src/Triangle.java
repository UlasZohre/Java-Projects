import java.util.ArrayList;

public class Triangle extends Tile {

    public Triangle() {
        Type = "Triangle";
        point = 15;
        Name = "T";
    }

    public String toString() {
        return Name;
    }

    public int Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y) {
        //only vertical up first left then down

        int counter = 1;



        if (x >= 2) {//vertical up x index will decrease
            if (map.get(x).get(y).getType().equals(map.get(x - 1).get(y).getType())) {
                counter++;
            }
            if (map.get(x).get(y).getType().equals(map.get(x - 2).get(y).getType())) {
                counter++;
            }

            if (counter == 3) {
                score = map.get(x).get(y).getPoint() + map.get(x - 1).get(y + 1).getPoint() +
                        map.get(x - 2).get(y + 2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x - 1).get(y).setName(" ");
                map.get(x - 2).get(y).setName(" ");
                return score;

            } else if (counter == 2) {
                counter = 1;
            }

        }

        if (x < map.size() - 2) {
            if (map.get(x).get(y).getType().equals(map.get(x + 1).get(y).getType())) {
                counter++;
            }
            if (map.get(x).get(y).getType().equals(map.get(x + 2).get(y).getType())) {
                counter++;

            }

            if (counter == 3) {
                score = map.get(x).get(y).getPoint() + map.get(x - 1).get(y + 1).getPoint() +
                        map.get(x - 2).get(y + 2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x + 1).get(y).setName(" ");
                map.get(x + 2).get(y).setName(" ");
                return score;

            }
        }
        return score;
    }
}