import java.util.ArrayList;

public class Plus extends MathOperators{

    public Plus(){
        Type = "+";
        point =20;
        isItMath = true;
        Name = "+";
    }
    public String toString(){
        return Name;
    }
    public int Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y) {
        //only horizontal axis first left then right

        int counter = 1;
        if ( y >= 2) { // left horizontal x will stay still y will decrease
            if (map.get(x).get(y-1).getIsItMath()){
                counter++;
            }

            if (map.get(x).get(y-2).getIsItMath()){
                counter++;
            }

            if(counter == 3){
                score = (3*map.get(x).get(y).getPoint());

                map.get(x).get(y).setName(" ");
                map.get(x).get(y-1).setName(" ");
                map.get(x).get(y-2).setName(" ");
                return score;
            }

            else{
                counter =1;
            }
        }

        if (y < map.get(x).size()-2) {
            if (map.get(x).get(y + 1).getIsItMath()) {
                counter++;
            }
            if (map.get(x).get(y + 2).getIsItMath()) {
                counter++;
            }

            if (counter == 3) {
                score = (3 * map.get(x).get(y).getPoint());

                map.get(x).get(y).setName(" ");
                map.get(x).get(y + 1).setName(" ");
                map.get(x).get(y + 2).setName(" ");
                return score;
            } else {
                counter = 1;
            }
            if (x >= 2) {//vertical up x index will decrease
                if (map.get(x - 1).get(y).getIsItMath()) {
                    counter++;
                }
                if (map.get(x - 2).get(y).getIsItMath()) {
                    counter++;
                }

                if (counter == 3) {
                    score = (3 * map.get(x).get(y).getPoint());

                    map.get(x).get(y).setName(" ");
                    map.get(x - 1).get(y).setName(" ");
                    map.get(x - 2).get(y).setName(" ");
                    return score;
                } else {
                    counter = 1;
                }
            }

            if (x < map.size() - 2) {
                if (map.get(x + 1).get(y).getIsItMath()) {
                    counter++;
                }

                if (map.get(x + 2).get(y).getIsItMath()) {
                    counter++;
                }
                if (counter == 3) {
                    score =  (3 * map.get(x).get(y).getPoint());

                    map.get(x).get(y).setName(" ");
                    map.get(x + 1).get(y).setName(" ");
                    map.get(x + 2).get(y).setName(" ");
                    return score;
                }
            }

        }
        return score;
    }
}
