import java.util.ArrayList;

public class Diamond extends Tile{

    public Diamond(){
        point = 30;
        Type = "Diamond";
        Name = "D";
    }

    public String toString(){
        return Name;
    }

    public int Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y){
        //you need to search 1-9-3-7 diagonals

        int counter = 1;// will check same type count with counter variable



        if (x >= 2 && y >= 2){//(1) left up diagonal both will decrease index wise
            if (map.get(x).get(y).getType().equals(map.get(x-1).get(y-1).getType())){
                counter++;
            }

            if (map.get(x).get(y).getType().equals(map.get(x-2).get(y-2).getType())){
                counter++;
            }

            if (counter == 3){
                score =  map.get(x).get(y).getPoint() +map.get(x-1).get(y-1).getPoint() +
                        map.get(x-2).get(y-2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x-1).get(y-1).setName(" ");
                map.get(x-2).get(y-2).setName(" ");

                return score;
            }

            else if (counter == 2){
                counter = 1;
            }
        }


        if ( x < map.size()-2 && y < map.get(x).size()-2 ){//(9) right down diagonal both will increase index wise
            if (map.get(x).get(y).getType().equals(map.get(x+1).get(y+1).getType())){
                counter++;
            }

            if (map.get(x).get(y).getType().equals(map.get(x+1).get(y+1).getType())){
                counter++;
            }

            if (counter == 3){
                score =  map.get(x).get(y).getPoint() +map.get(x+1).get(y+1).getPoint() +
                        map.get(x+2).get(y+2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x+1).get(y+1).setName(" ");
                map.get(x+2).get(y+2).setName(" ");

                return score;
            }

            else if (counter == 2){
                counter = 1;
            }

        }

        if (x >= 2 && y < map.get(x).size()-2){ //(3) right up diagonal x will decrease y will increase index wise
            if (map.get(x).get(y).getType().equals(map.get(x-1).get(y+1).getType())){
                counter++;
            }

            if (map.get(x).get(y).getType().equals(map.get(x-2).get(y+2).getType())){
                counter++;
            }

            if (counter == 3){/*if counter is 3 then we got the triplet that we want
                    and we ll take their point and break the loop
                    */
                score +=  map.get(x).get(y).getPoint() +map.get(x-1).get(y+1).getPoint() +
                        map.get(x-2).get(y+2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x-1).get(y+1).setName(" ");
                map.get(x-2).get(y+2).setName(" ");

                return score;
            }

            else if (counter == 2){
                counter = 1;
            }

        }

        if (x < map.size()-2 && y >= 2){//(7) left down diagonal x will increase y will decrease
            if (map.get(x).get(y).getType().equals(map.get(x+1).get(y-1).getType())){
                counter++;
            }

            if (map.get(x).get(y).getType().equals(map.get(x+2).get(y-2).getType())){
                counter++;
            }

            if (counter == 3){
                score =  map.get(x).get(y).getPoint() +map.get(x+1).get(y-1).getPoint() +
                        map.get(x+2).get(y-2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x+1).get(y-1).setName(" ");
                map.get(x+2).get(y-2).setName(" ");

                return score;
            }
        }

    return score;
    }
}
