import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Movement {

    public Movement(ArrayList<ArrayList<Tile>> map, String Name, int Point, ArrayList<ArrayList> commands) throws IOException {
        /* Map contains array lists that contain tiles
           commands contains array lists that contain ints
        */

        FileWriter fwMonitor  = new FileWriter("monitoring.txt");
        BufferedWriter bwMonitor = new BufferedWriter(fwMonitor);


        int PlayerIndex = 0;

        for (int i = 0; i < PlayerList.getPlayerlist().size(); i++){
            if (Name.equals(PlayerList.getPlayerlist().get(i).getName())){
                PlayerIndex = i;
            }
        }


        bwMonitor.write("Game grid: \n" + "\n");
        for (int i = 0; i < map.size(); i++){
            for (int j = 0; j< map.get(i).size(); j++){
                bwMonitor.write(map.get(i).get(j).getName() + " ");
            }
            bwMonitor.write("\n");
        }
        for (int i = 0; i < map.size(); i++){
            for (int j = 0; j< map.get(i).size(); j++){
                System.out.print(map.get(i).get(j).getName() + " ");
            }
            System.out.print("\n");
        }


        for (int i = 0; i < commands.size(); i++){
            int x = (int) commands.get(i).get(0);// x coordinate
            int y = (int) commands.get(i).get(1);// y coordinate
            int score = 0;

            if (x >= 0 && x< map.size() && y>=0 && y < map.get(x).size()){

                bwMonitor.write("\n"+"Select coordinate or enter E to end the game: " + x +  " " + y + "\n"
                        + "\n");

                score = map.get(x).get(y).Move(map, score, x, y);
                ArrangeMap.arrangeMap(map);

                for (int i2 = 0; i2 < map.size(); i2++){
                    for (int j2 = 0; j2< map.get(i2).size(); j2++){
                        bwMonitor.write(map.get(i2).get(j2).getName() + " ");
                    }
                    bwMonitor.write("\n");

                }
                bwMonitor.write("\n");
                bwMonitor.write("Score:" + score+ "\n" + "\n");
            }
            else {
                bwMonitor.write("Please enter a valid coordinate.");
            }

            Point = Point + score;
        }
        Player player = PlayerList.getPlayerlist().get(PlayerIndex);
        PlayerList.getPlayerlist().get(PlayerIndex).setPoint(Point);

        Collections.sort(PlayerList.getPlayerlist());

        int PlayerIndex2 = Collections.binarySearch(PlayerList.getPlayerlist(), player);

        bwMonitor.write("Select coordinate or enter E to end the game: " + "E"+ "\n" + "\n");
        bwMonitor.write("Total Score: " + Point+ "\n" + "\n");
        bwMonitor.write("Enter Name: " + Name + "\n" + "\n");



        if (PlayerIndex2 == 0){
            bwMonitor.write("Your rank is " + (PlayerIndex2+1) + "/" + PlayerList.getPlayerlist().size() +
                    " your score is " + (PlayerList.getPlayerlist().get(0).getPoint()-PlayerList.getPlayerlist().get(1).getPoint())
                    + " higher than " + PlayerList.getPlayerlist().get(1).getName());
        }

        else if (PlayerIndex2 == PlayerList.getPlayerlist().size()-1){
            bwMonitor.write("Your rank is " + (PlayerIndex2+1) + "/" + PlayerList.getPlayerlist().size() +
                    " your score is " + (PlayerList.getPlayerlist().get(PlayerIndex2-1).getPoint()-
                    PlayerList.getPlayerlist().get(PlayerIndex2).getPoint()) + " lower than " +
                    PlayerList.getPlayerlist().get(PlayerIndex2-1).getName());
        }


        else{
            bwMonitor.write("Your rank is " + (PlayerIndex2+1) + "/" + PlayerList.getPlayerlist().size() +
                    " your score is " + (PlayerList.getPlayerlist().get(PlayerIndex2-1).getPoint()-
                    PlayerList.getPlayerlist().get(PlayerIndex2).getPoint()) + " lower than " +
                    PlayerList.getPlayerlist().get(PlayerIndex2-1).getName() + " and " +
                    (PlayerList.getPlayerlist().get(PlayerIndex2).getPoint()- PlayerList.getPlayerlist().get(PlayerIndex2+1).getPoint())
                    + " higher than " + PlayerList.getPlayerlist().get(PlayerIndex2+1).getName());
        }








        bwMonitor.write( "\n"+"\n"+ "Goodbye! \n");

        bwMonitor.close();

        FileWriter fwLeaderBoard = new FileWriter("leaderboard.txt");
        BufferedWriter bwLeader = new BufferedWriter(fwLeaderBoard);

        for (int u = 0; u < PlayerList.getPlayerlist().size(); u++){
            bwLeader.write(PlayerList.getPlayerlist().get(u).getName() + " " +
                    PlayerList.getPlayerlist().get(u).getPoint() + "\n");
        }

        bwLeader.close();





    }
}
