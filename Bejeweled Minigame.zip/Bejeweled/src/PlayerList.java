import java.util.ArrayList;

public class PlayerList {

    public static ArrayList<Player> Playerlist = new ArrayList<>();//this will hold players


    public static ArrayList<Player> getPlayerlist() {//getter method

        return Playerlist;
    }


    public static ArrayList<Player> setPlayerlist (Player obj){//Setter method
        Playerlist.add(obj);

        return Playerlist;
    }



}
