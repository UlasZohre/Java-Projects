import java.util.ArrayList;

public class StraightLine extends MathOperators{

    public StraightLine(){
        Type = "|";
        point = 20;
        isItMath = true;
        Name = "|";
    }
    public String toString(){
        return Name;
    }
    public int Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y) {
        //only vertical up first left then down

        int counter = 1;


        if (x >= 2) {//vertical up x index will decrease
            if (map.get(x-1).get(y).getIsItMath()){
                counter++;
            }
            if (map.get(x-2).get(y).getIsItMath()){
                counter++;
            }

            if (counter == 3){
                score = (3*map.get(x).get(y).getPoint());

                map.get(x).get(y).setName(" ");
                map.get(x-1).get(y).setName(" ");
                map.get(x-2).get(y).setName(" ");
                return score;
            }
            else{
                counter = 1;
            }
        }

        if (x < map.size() - 2) {
            if (map.get(x+1).get(y).getIsItMath()){
                counter++;
            }

            if (map.get(x+2).get(y).getIsItMath()){
                counter++;
            }
            if (counter == 3) {
                score = (3 * map.get(x).get(y).getPoint());

                map.get(x).get(y).setName(" ");
                map.get(x + 1).get(y).setName(" ");
                map.get(x + 2).get(y).setName(" ");
                return score;
            }
        }
        return score;
    }
}
