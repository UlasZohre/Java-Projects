import java.util.ArrayList;

public class Divide extends MathOperators{

    public Divide(){
        Type = "/";
        point = 20;
        isItMath = true;
        Name = "/";
    }
    public String toString(){
        return "/";
    }

    public int  Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y){

        int counter = 1;

        if (x >= 2 && y < map.get(x).size()-2){
            //(3) right up diagonal x will decrease y will increase index wise


            if (map.get(x-1).get(y+1).getIsItMath()){
                counter++;
            }
            if (map.get(x-2).get(y+2).getIsItMath()){
                counter++;
            }

            if (counter ==3){
                score=  map.get(x).get(y).getPoint() + map.get(x-1).get(y+1).getPoint() +
                        map.get(x-2).get(y+2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x-1).get(y-1).setName(" ");
                map.get(x-2).get(y-2).setName(" ");
                return score;
            }
            else{
                counter = 1;
            }
        }

        else if (x < map.size()-2 && y >= 2){//(7) left down diagonal x will increase y will decrease
            if (map.get(x+1).get(y-1).getIsItMath()){
                counter++;
            }

            if (map.get(x+2).get(y-2).getIsItMath()){
                counter++;
            }

            if (counter== 3){
                score = map.get(x).get(y).getPoint() + map.get(x+1).get(y-1).getPoint() +
                        map.get(x+2).get(y-2).getPoint();


                map.get(x).get(y).setName(" ");
                map.get(x+1).get(y-1).setName(" ");
                map.get(x+2).get(y-2).setName(" ");
                return score;
            }

            else{
                counter = 1;
            }

        }

        return score ;


    }
}
