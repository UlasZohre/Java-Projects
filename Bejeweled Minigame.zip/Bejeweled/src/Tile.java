import java.util.ArrayList;

public class Tile {//biggest class everyone extends from this

    public String Type = " ";//we will look this parameter to check locations are equals or not
    public int point = 0;
    public String Name = " ";

    public Boolean isItMath = false;//math operator will take special treat

    public String getType(){
        return Type;
    }

    public int getPoint(){
        return point;
    }

    public String setType(String str){//maybe we will use this for wildcards
        this.Type = str;
        return Type;
    }


    public Boolean getIsItMath(){
        return isItMath;
    }//to check if its math or not

    public int Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y){
        return score;
    }

    public String getName(){
        return Name;
    }

    public String setName(String str){
        this.Name = str;
        return Name;
    }

}
