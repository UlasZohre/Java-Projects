import java.util.ArrayList;

public class Square extends Tile{

    public Square(){
        Type = "Square";
        point = 15;
        Name = "S";
    }
    public String toString(){
        return Name;
    }

    public int Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y){
        //only horizontal axis first left then right

        int counter = 1;


        if ( y >= 2){ // left horizontal x will stay still y will decrease
            if (map.get(x).get(y).getType().equals(map.get(x).get(y-1).getType())){
                counter++;
            }

            if (map.get(x).get(y).getType().equals(map.get(x).get(y-2).getType())){
                counter++;
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() + map.get(x).get(y-1).getPoint() +
                        map.get(x).get(y-2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x).get(y-1).setName(" ");
                map.get(x).get(y-2).setName(" ");
                return score;
            }

            else if (counter == 2){
                counter = 1;
            }
        }

        if (y < map.get(x).size()-2){
            if (map.get(x).get(y).getType().equals(map.get(x).get(y+1).getType())){
                counter++;
            }

            if(map.get(x).get(y).getType().equals(map.get(x).get(y+2).getType())){
                counter++;
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() + map.get(x).get(y+1).getPoint() +
                        map.get(x).get(y+2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x).get(y+1).setName(" ");
                map.get(x).get(y+2).setName(" ");
                return score;
            }
        }

        return score;
    }
}
