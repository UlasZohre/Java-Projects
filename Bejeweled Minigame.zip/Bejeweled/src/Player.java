public class Player implements Comparable<Player>{

    int point = 0;//player's point
    String Name = " ";//player's name



    public Player(String name){
        this.Name = name;


    }

    public Player(String name, int point){
        this.Name = name;
        this.point = point;
    }


    @Override
    public int compareTo(Player o) {//will need for tree set
        return o.point-this.point;
    }

    public int setPoint(int point){
        this.point = point;
        return this.point;
    }



    public int getPoint(){
        return point;
    }

    public String getName(){
        return Name;
    }

    public String toString(){
        return Name;
    }

}
