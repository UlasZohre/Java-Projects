import java.util.ArrayList;

public class Wildcard extends Tile {

    public Wildcard() {
        Type = "Wildcard";
        point = 10;
        Name = "W";
    }

    public String toString() {
        return Name;
    }


    public int Move(ArrayList<ArrayList<Tile>> map, int score, int x, int y) {
        /*starts searching from vertical (2 and 8) followed by horizontal (4 and 6) and
        finally diagonals left (1 and 9) and right (3 and 7).*/


        int counter = 1;

        //Verticals first

        if (x >= 2) {//vertical up x index will decrease

            if (map.get(x).get(y).getType().equals(map.get(x-1).get(y).getType()) ||
                    !(map.get(x-1).get(y).getIsItMath())){
                counter++;
            }


            if (map.get(x-1).get(y).getType().equals("Wildcard")){

                if (!map.get(x-2).get(y).getIsItMath()){
                    counter++;
                }
            }

            else{
                if (map.get(x-1).get(y).getType().equals(map.get(x-2).get(y).getType())){
                    counter++;
                }
            }

            if (counter == 3){

                score = map.get(x).get(y).getPoint() + map.get(x-1).get(y).getPoint() +
                        map.get(x-2).get(y).getPoint();


                map.get(x).get(y).setName(" ");
                map.get(x-1).get(y).setName(" ");
                map.get(x-2).get(y).setName(" ");
                return score;
            }

            else{
                counter = 1;
            }
        }

        if (x < map.size() - 2) {

            if (map.get(x).get(y).getType().equals(map.get(x+1).get(y).getType()) ||
                !map.get(x+1).get(y).getIsItMath()){
                counter++;
            }

            if (map.get(x+1).get(y).getType().equals("Wildcard")){
                if (!map.get(x+2).get(y).getIsItMath()){
                    counter++;
                }
            }

            else{
                if (map.get(x+1).get(y).getType().equals(map.get(x+2).get(y).getType())){
                    counter++;
                }
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() + map.get(x+1).get(y).getPoint()
                        + map.get(x+2).get(y).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x+1).get(y).setName(" ");
                map.get(x+2).get(y).setName(" ");
                return score;
            }


        }

        //horizontal second

        if (y >= 2){//first left side

            if (map.get(x).get(y).getType().equals(map.get(x).get(y-1).getType())||
                !map.get(x).get(y-1).getIsItMath()){//cause its wildcard we can take everything except for math
                counter++;
            }

            if (map.get(x).get(y-1).getType().equals("Wildcard")){//if its wildcard we can take every jewel
                if (!map.get(x).get(y-2).getIsItMath()){
                    counter++;
                }

            }

            else{
                if (map.get(x).get(y-1).getType().equals(map.get(x).get(y-2).getType())){
                    counter++;
                }
            }

            if (counter == 3){
                score=  map.get(x).get(y).getPoint() + map.get(x).get(y-1).getPoint()
                        + map.get(x).get(y-2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x).get(y-1).setName(" ");
                map.get(x).get(y-2).setName(" ");
                return score;
            }

            else{
                counter = 1;
            }
        }

        if (y < map.get(x).size()-2){// then right side

            if (!map.get(x).get(y+1).getIsItMath()){
                counter++;
            }

            if (map.get(x).get(y+1).getType().equals("Wildcard")){
                if (!map.get(x).get(y+2).getIsItMath()){
                    counter++;
                }
            }
            else{
                if (map.get(x).get(y+1).getType().equals(map.get(x).get(y+2).getType())){
                    counter++;
                }
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() + map.get(x).get(y+1).getPoint()
                        + map.get(x).get(y+2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x).get(y+1).setName(" ");
                map.get(x).get(y+2).setName(" ");
                return score;
            }

            else{
                counter = 1;
            }

        }


        //lastly diagonals
        if (x >= 2 && y >= 2) {//(1) left up diagonal both will decrease index wise
            if (!map.get(x-1).get(y-1).getIsItMath()){
                counter++;
            }

            if (map.get(x-1).get(y-1).getType().equals("Wildcard")){
                if (!map.get(x-2).get(y-2).getIsItMath()){
                    counter++;
                }
            }

            else{
                if (map.get(x-1).get(y-1).getType().equals(map.get(x-2).get(y-2).getType())){
                    counter++;
                }
            }

            if (counter == 3){
                score = map.get(x-1).get(y-1).getPoint() + map.get(x).get(y).getPoint()+
                        map.get(x-2).get(y-2).getPoint();


                map.get(x).get(y).setName(" ");
                map.get(x-1).get(y-1).setName(" ");
                map.get(x-2).get(y-2).setName(" ");
                return score;
            }
            else{
                counter = 1;
            }
        }

        if ( x < map.size()-2 && y < map.get(x).size()-2 ){//(9) right down diagonal both will increase index wise

            if (!map.get(x+1).get(y+1).getIsItMath()){
                counter++;
            }

            if (map.get(x+1).get(y+1).getType().equals("Wildcard")) {
                if (!map.get(x+2).get(y+2).getIsItMath()){
                    counter++;
                }
            }

            else{
                if (map.get(x+1).get(y+1).getType().equals(map.get(x+2).get(y+2).getType())){
                    counter++;
                }
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() + map.get(x+1).get(y+1).getPoint() +
                        map.get(x+2).get(y+2).getPoint();


                map.get(x).get(y).setName(" ");
                map.get(x+1).get(y+1).setName(" ");
                map.get(x+2).get(y+2).setName(" ");
                return score;
            }

            else{
                counter = 1;

            }
        }

        else if (x >= 2 && y < map.get(x).size()-2) { //(3) right up diagonal x will decrease y will increase index wise

            if (!map.get(x-1).get(y+1).getIsItMath()){
                counter++;
            }

            if (map.get(x-1).get(y+1).getType().equals("Wildcard")){
                if (!map.get(x-2).get(y+2).getIsItMath()){
                    counter++;
                }
            }
            else{
                if (map.get(x-1).get(y+1).getType().equals(map.get(x-2).get(y+2).getType())){
                    counter++;
                }
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() + map.get(x-1).get(y+1).getPoint() +
                        map.get(x-2).get(y+2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x-1).get(y+1).setName(" ");
                map.get(x-2).get(y-2).setName(" ");
                return score;
                }

            else{
                counter = 1;
            }

        }


        else if (x < map.size()-2 && y >= 2) {//(7) left down diagonal x will increase y will decrease

            if (!map.get(x+1).get(y-1).getIsItMath()){
                counter++;
            }

            if (map.get(x+1).get(y-1).getType().equals("Wildcard")){
                if (!map.get(x+2).get(y-2).getIsItMath()){
                    counter++;
                }
            }

            else{
                if (map.get(x+1).get(y-1).getType().equals(map.get(x+2).get(y-2).getType())){
                    counter++;
                }
            }

            if (counter == 3){
                score = map.get(x).get(y).getPoint() + map.get(x+1).get(y-1).getPoint() +
                        map.get(x+2).get(y-2).getPoint();

                map.get(x).get(y).setName(" ");
                map.get(x+1).get(y-1).setName(" ");
                map.get(x+2).get(y-2).setName(" ");
                return score;
            }

            else{
                counter = 1;
            }
        }
        return score;
    }
}
