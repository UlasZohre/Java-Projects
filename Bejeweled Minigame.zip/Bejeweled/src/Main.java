import java.io.File;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        File GameGrid = new File(args[0]);// this will read args0 aka gameGrid.txt

        Map map = new Map(GameGrid);//this will create game board
        File leaderboards = new File("leaderboard.txt");// this will read leaderboard(?)

        LeaderboardReader leaderboardReader = new LeaderboardReader(leaderboards);//sending leaderboard file to proper class

        File command = new File(args[1]);//this will read args1 aka command.txt

        CommandReader commandReader = new CommandReader(command, map.getBoard()); // sending command file to proper class






    }
}
