import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class LeaderboardReader {

    public LeaderboardReader(File file) throws IOException {

        Scanner LBScanner = new Scanner(file);

        while (LBScanner.hasNextLine()){
            String[] SplitLine = LBScanner.nextLine().split(" ");//we split line to access name and points

            int PlayerPoints = Integer.parseInt(SplitLine[1]);// we convert point to int from string

            Player newPlayer = new Player(SplitLine[0], PlayerPoints);// new player created

            PlayerList.setPlayerlist(newPlayer);// new player added to arraylist


        }

    }
}
