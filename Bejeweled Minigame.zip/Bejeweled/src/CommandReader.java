import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CommandReader {

    ArrayList<ArrayList> commandList = new ArrayList<>();
    int points = 0;
    String Name = " ";

    public CommandReader(File file, ArrayList<ArrayList<Tile>> Map) throws IOException {


        Scanner commandReader = new Scanner(file);




        while (commandReader.hasNextLine()){
            String Line = commandReader.nextLine();
            ArrayList<Integer> tempComList = new ArrayList<>();

            if (Line.length() == 3){// if line has 3 character that means line has coordinates
                String[] line = Line.split(" ");//split characters
                int command1 = Integer.parseInt(line[0]);//convert string to int
                int command2 = Integer.parseInt(line[1]);
                tempComList.add(command1);//add newly converted ints to temp list
                tempComList.add(command2);
                setCommandList(tempComList);// add temp list to real list
            }

            else if (Line.length() == 1){// if line is E nothing will happen

            }

            else{

                Name = Line;
                if (PlayerList.getPlayerlist().contains(Name) ){//checking if player played before or not


                    for (int i = 0; i< PlayerList.getPlayerlist().size(); i++){
                        // if player played before we ll take his previous score to add
                        if (PlayerList.getPlayerlist().get(i).getName().equals(Line)){//just getters
                            points = PlayerList.getPlayerlist().get(i).getPoint();
                        }
                    }
                }

                else{//if not we will create new player
                    Player newPlayer = new Player(Name);//creating new player to add

                    PlayerList.setPlayerlist(newPlayer);//adding player to player arraylist

                }
            }




        }

        Movement newMove = new Movement(Map, Name, points, commandList);

    }


    public ArrayList<ArrayList> setCommandList(ArrayList<Integer> ar){
        commandList.add(ar);
        return commandList;
    }

    public ArrayList<ArrayList> getCommandList(){
        return commandList;
    }

    public int getPoints(){
        return points;
    }

    public String getName(){
        return Name;
    }










}
